package juegoCodigo;

//es una clase de ennumerado para contar los palos de la baraja
public enum Palos {
    BASTO,
    COPA,
    ESPADA,
    ORO;
}
